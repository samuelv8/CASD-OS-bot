# Bot da OS

Por favor, editr esse arquivo. O link abaixo pode ajudar nisso.

You can use [Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.
